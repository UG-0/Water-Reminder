This program has no setup file so you will have to do it yourself  (you need administrator to do this)

Part 1: Allowing the program to save it's data

Step 1: move the Water Count folder into C:\Users\Public\Public Desktop

Part 2: Giving the program permission to work in the public desktop

Step 1: right click on the "Water Count" folder (the folder which has this file in it)
Step 2: click on properties
Step 3: Click on security
Step 4: Click on Advanced
Step 5: Click on the Add button (if it is not showing up click on the change permissions button the "Add" button will show up)
Step 6: infront of the principal category press on the button called "Select Principal"
Step 7: in the "Enter the object name to select (examples)" field type users and press ok
Step 8: Click on the full control check box and press ok on all the windows we opened before 

Part 3: Allowing the program to run on start up

Step 1: press win+r
Step 2: type shell:startup into run window
Step 3: move the "Paste me into shellstartup" file there

Things to remember to use the program:
clicking on yes will add 1 glass clicking on no will remove 1 and clicking on done will close the program but not from the background
if you find any bug in the program dm me on discord @ug._.
                                                                                                                         the program will now start at startup and will run in the background
                                                                                                                       it will not be a recource hog and will alert you to drink water every 1 hr                                           
                                                                                                                                Done! if you encounter any issues DM me on discord @ug._.